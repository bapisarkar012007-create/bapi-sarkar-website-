const Razorpay = require("razorpay");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

module.exports = async (req, res) => {

  try {

    const order = await razorpay.orders.create({
      amount: 1500,
      currency: "INR",
      receipt: "ssc_chsl_pdf"
    });

    res.status(200).json({
      success: true,
      keyId: process.env.RAZORPAY_KEY_ID,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency
    });

  } catch(error){

    res.status(500).json({
      success:false,
      error:error.message
    });

  }

};