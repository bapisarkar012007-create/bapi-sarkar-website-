const crypto = require("crypto");

module.exports = async (req, res) => {

try {

const {
razorpay_order_id,
razorpay_payment_id,
razorpay_signature
}=req.body;


const body =
razorpay_order_id + "|" + razorpay_payment_id;


const expectedSignature =
crypto
.createHmac(
"sha256",
process.env.RAZORPAY_KEY_SECRET
)
.update(body)
.digest("hex");


res.json({
verified:
expectedSignature === razorpay_signature
});


}
catch(error){

res.status(500).json({
verified:false
});

}

};